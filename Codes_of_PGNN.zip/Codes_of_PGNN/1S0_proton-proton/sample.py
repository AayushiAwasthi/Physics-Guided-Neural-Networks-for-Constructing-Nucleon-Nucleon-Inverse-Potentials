import warnings
warnings.filterwarnings('ignore')
import numpy as np
import csv
import numba
from numpy import pi, exp, sqrt, cos, sin

# Constants
M_p = 938.272046  # MeV/c^2
M_n = 938.272046  # MeV/c^2
hbarc = 197.3269718  # MeV fm
mu = (M_n * M_p) / (M_n + M_p)
den = (hbarc**2) / mu
den2 = (hbarc**2) / (2 * mu)
rad2deg = 180.0 / pi

# Energy and phase shifts for 1S0 channel (experimental)
E = np.array([1, 5, 10, 25, 50, 100, 150, 200, 250, 300, 350]).astype(np.float64)
pS = np.array([0.5705, 0.9554, 0.9614, 0.8469, 0.6767, 0.4364, 0.2618, 0.1220, 0.0040, -0.0985, -0.1896]).astype(np.float64)

# Step size for RK
h = 0.01
h_4 = h / 4
h_8 = h / 8
h_2 = h / 2
h_34 = h * 0.75
h_3_16 = h * 3 / 16
h_9_16 = h * 9 / 16
h_3_7 = h * 3 / 7
h_12_7 = h * 12 / 7
h_90 = h / 90
h_8_7 = h * 8 / 7
h_2_7 = h * 2 / 7

# Generate Morse potential parameters
def generate_morse_params():
    a1 = np.random.uniform(-300, 300) ###Vr
    a2 = np.random.uniform(-100, 100)  ####Va
    a3 = np.random.uniform(0.01, 4)  ##ua
    return a1, a2, a3

# Morse potential function
def morse_potential(a1, a2, a3, x):
    return ((a1*exp(-2*a3*x) -a2*exp(-a3*x) ) *(x**(-1))) +((0.03472*5**-1)*(exp(-x*5**-1))*(1-exp(-x*5**-1))**(-1))

# Function f for RK method
@numba.jit(nopython=True)
def f(x_in, y_in, v_new):
    k11 = sqrt(E / den)
    k_2 = k11 ** -1
    kx = k11 * x_in
    return -k_2 * v_new * (cos(y_in) * sin(kx) + sin(y_in) * cos(kx)) ** 2

# Runge-Kutta method to solve the differential equation

@numba.jit(nopython=True)
def rk_method(v_new):
    idx = 0
    x = 0.01
    k11 = sqrt(E / den)
    y = np.zeros_like(k11)
    for _ in range(2000):
        k1 = f(x, y, v_new[idx])
        k2 = f(x + h_4, y + h_4 * k1, v_new[idx + 1])
        k3 = f(x + h_4, y + h_8 * (k1 + k2), v_new[idx + 1])
        k4 = f(x + h_2, y - h_2 * k2 + h * k3, v_new[idx + 2])
        k5 = f(x + h_34, y + h_3_16 * k1 + h_9_16 * k4, v_new[idx + 3])
        k6 = f(x + h, y - h_3_7 * k1 + h_2_7 * k2 + h_12_7 * (k3 - k4) + h_8_7 * k5, v_new[idx + 4])
        y = y + h_90 * (7 * k1 + 32 * k3 + 12 * k4 + 32 * k5 + 7 * k6)
        idx += 4
        x += h
    return y

# Main execution: generate random Morse potentials and compute phase shifts, writing to CSV
def compute_and_save_phase_shifts(num_samples=10000):
    x = np.arange(0.01, 20.0125, 0.0025)

    # Open a CSV file to write the results
    with open('morse_phase_shifts.csv', 'w', newline='') as csvfile:
        csvwriter = csv.writer(csvfile)
        # Write the header
        header = ["Vr", "Va", "ua"] + [f"Phase_Shift_" for i in range(len(pS))] + ["mape"]
        csvwriter.writerow(header)

        for _ in range(num_samples):
            while True:  # Keep generating until we get valid phase shifts in [-pi, pi]
                a1, a2, a3 = generate_morse_params()
                v_new = morse_potential(a1, a2, a3, x)
                delta = rk_method(v_new)  # Solve the equation using RK method

                # Check if the phase shifts are within the range [-pi, pi]
                if np.all((-pi <= delta) & (delta <= pi)):
                    break  # Valid phase shifts, exit the loop

            # Calculate mean squared error (mape) between experimental and simulated phase shifts
            mse = np.mean((pS - delta)**2)
            #mape = np.mean(np.abs((pS - delta) / delta)) * 100


            # Write V0, a, re, simulated phase shifts, and mape to the CSV file
            row = [a1, a2, a3] + delta.tolist() + [mse]
            csvwriter.writerow(row)

# Run the computation and save the results
compute_and_save_phase_shifts()
