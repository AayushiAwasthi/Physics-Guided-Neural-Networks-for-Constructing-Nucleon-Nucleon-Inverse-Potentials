import warnings
warnings.filterwarnings('ignore')
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

# Load the pre-trained models
model_F1 = keras.models.load_model('model_F1.h5')
model_F2 = keras.models.load_model('model_F2.h5')

# Define the scalers (ManVrlly fitting the scaler with known ranges)
input_scaler = MinMaxScaler(feature_range=(-1, 1))  # Input scaler for Vr and phase shifts
output_scaler_F1 = MinMaxScaler(feature_range=(-1, 1))  # Output scaler for am
output_scaler_F2 = MinMaxScaler(feature_range=(-1, 1))  # Output scaler for rm

# Experimental phase shifts (constant for all Vr)
#exp_phase_shifts = [62.105, 63.689, 60.038, 51.011, 40.644, 26.772, 16.791, 8.759, 1.982, -3.855, -8.923]
exp_phase_shifts = [1.0826, 1.1071, 1.0436, 0.8835, 0.6997, 0.4542, 0.2789, 0.1396, 0.0223, -0.0793, -0.1695
]

# Fit the input scaler with known ranges
# Assume Vr ranges from [0, 10] and phase shifts range from [-np.pi, np.pi]
input_scaler.fit(np.array([[0.01, -np.pi, -np.pi, -np.pi, -np.pi, -np.pi, -np.pi, -np.pi, -np.pi, -np.pi, -np.pi, -np.pi], 
                           [4, np.pi, np.pi, np.pi, np.pi, np.pi, np.pi, np.pi, np.pi, np.pi, np.pi, np.pi]]))

# Fit the output scalers for am and rm with their known ranges
# Assume Vr ranges from [0.01, 10000] and Va ranges from [0.01, 5000]
# output_scaler_F1.fit(np.array([[0.01], [3]]))  # For ua
# output_scaler_F2.fit(np.array([[-100], [100]]))  # For Va


from joblib import load
input_scaler = load('input_scaler.pkl')
output_scaler_F1 = load('output_scaler_F1.pkl')
output_scaler_F2 = load('output_scaler_F2.pkl')


# Initialize an empty list to store results
results = []


for ua in np.arange(0.01, 4, 0.025):
    # Combine the input (Vr and experimental phase shifts) into a single array
    input_data = np.array([ua] + exp_phase_shifts).reshape(1, -1)
    
    # Apply input normalization
    input_data_scaled = input_scaler.transform(input_data)
    
    # Predict am using model_F1
    a_m_hat_scaled = model_F1.predict(input_data_scaled)
    a_m_hat = output_scaler_F1.inverse_transform(a_m_hat_scaled)  # Convert back to original scale
    
    # Prepare input for model_F2 by appending the predicted am to the original scaled input
    input_data_F2 = np.hstack((input_data_scaled, a_m_hat_scaled))
    
    # Predict rm using model_F2
    r_m_hat_scaled = model_F2.predict(input_data_F2)
    r_m_hat = output_scaler_F2.inverse_transform(r_m_hat_scaled)  # Convert back to original scale
    
    # Store the result in the list
    results.append([ua, a_m_hat[0][0], r_m_hat[0][0]])

# Convert the results list into a DataFrame
df_results = pd.DataFrame(results, columns=['ua', 'Va', 'Vr'])

# Save the DataFrame to a CSV file
df_results.to_csv('predicted_Va_Vr.csv', index=False)

# Log message to confirm output
print("Results saved to predicted_Va_Vr.csv.csv")
