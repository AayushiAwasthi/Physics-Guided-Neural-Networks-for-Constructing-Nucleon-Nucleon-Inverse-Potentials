import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def calculate_mse(ua, Va, Vr, p3s1):
    M_p = 939.565379 
    M_n = 939.565379 
    hbarc = 197.3269718 
    mu = (M_n * M_p) / (M_n + M_p)
    den = (hbarc**2) / (2 * mu)
    den1 = (hbarc**2) / mu

    E3s1 = np.array([1, 5, 10, 25, 50, 100, 150, 200, 250, 300, 350])  
    k = np.sqrt(E3s1 / den1)

    def f(x, y):
        term1 = (Vr * np.exp(-2 * ua * x) - Va * np.exp(-ua * x)) / x
        term2 = (np.cos(y) * np.sin(k * x) + np.sin(y) * np.cos(k * x)) ** 2
        return (-1 / k) * term1 * term2

    y = 0
    h = 0.01
    for i in range(500):
        x = 0.01 + i * h
        k1 = f(x, y)
        k2 = f(x + h/4, y + h * k1 / 4)
        k3 = f(x + h/4, y + h * k1 / 8 + h * k2 / 8)
        k4 = f(x + h/2, y - h * k2 / 2 + h * k3)
        k5 = f(x + 3*h/4, y + 3*h*k1/16 + 9*h*k4/16)
        k6 = f(x + h, y - 3*h*k1/7 + 2*h*k2/7 + 12*h*k3/7 - 12*h*k4/7 + 8*h*k5/7)
        
        y += h * (7*k1 + 32*k3 + 12*k4 + 32*k5 + 7*k6) / 90

    p3s1sim = y * 180 / np.pi  # degrees (optional, for visualization)

    mse = np.mean((p3s1 - y) ** 2)
    return mse

# Load predicted potentials
data = pd.read_csv('predicted_Va_Vr.csv')

ua_values = data['ua'].values
Va_values = data['Va'].values
Vr_values = data['Vr'].values

# True phase shifts p3s1 (fixed)
p3s1 = np.array([0.9962, 1.0585, 1.0032, 0.8518, 0.6713, 0.4268, 0.2510, 0.1106, -0.0073, -0.1101, -0.2013])

mse_results = []

for ua, Va, Vr in zip(ua_values, Va_values, Vr_values):
    mse = calculate_mse(ua, Va, Vr, p3s1)
    mse_results.append(mse)
    print(f"ua={ua:.4f}, Va={Va:.4f}, Vr={Vr:.4f}, MSE={mse:.8f}")

# Save MSE results
df_mse = pd.DataFrame({
    'ua': ua_values,
    'Va': Va_values,
    'Vr': Vr_values,
    'MSE': mse_results
})

df_mse.to_csv('MSE_results.csv', index=False)

# Find minimum MSE and corresponding parameters
min_idx = np.argmin(mse_results)
print("\nMinimum MSE and corresponding parameters:")
print(df_mse.iloc[min_idx])

# Plot ua vs MSE
plt.figure(figsize=(10, 6))
plt.plot(ua_values, mse_results, 'b-o')
plt.xlabel('ua (fm)')
plt.ylabel('Mean Squared Error')
plt.title('MSE vs ua')
plt.grid(True)
plt.savefig('MSE_vs_ua.png', dpi=300)
plt.show()
