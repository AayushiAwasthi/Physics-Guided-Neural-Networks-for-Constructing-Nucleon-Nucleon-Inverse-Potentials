import warnings
warnings.filterwarnings('ignore')
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
import joblib  # Import joblib to save scalers
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.losses import Huber
from tensorflow.keras import layers

# Load the dataset
data = pd.read_csv('input_data.csv')  
# Update the path to your CSV file

# Specify the input columns and output columns
input_columns = ['ua', 'Phase_Shift_1', 'Phase_Shift_2', 'Phase_Shift_3', 
                 'Phase_Shift_4', 'Phase_Shift_5', 'Phase_Shift_6', 
                 'Phase_Shift_7', 'Phase_Shift_8', 'Phase_Shift_9', 
                 'Phase_Shift_10', 'Phase_Shift_11']  
output_columns_F1 = ['Va']
output_columns_F2 = ['Vr']

# Normalize the inputs
input_scaler = MinMaxScaler(feature_range=(-1, 1))
data[input_columns] = input_scaler.fit_transform(data[input_columns])

# Normalize outputs
output_scaler_F1 = MinMaxScaler(feature_range=(-1, 1))
data[output_columns_F1] = output_scaler_F1.fit_transform(data[output_columns_F1])

output_scaler_F2 = MinMaxScaler(feature_range=(-1, 1))
data[output_columns_F2] = output_scaler_F2.fit_transform(data[output_columns_F2])

# Save the scalers
joblib.dump(input_scaler, 'input_scaler.pkl')
joblib.dump(output_scaler_F1, 'output_scaler_F1.pkl')
joblib.dump(output_scaler_F2, 'output_scaler_F2.pkl')

# Split the data into features and targets
X = data[input_columns]
y_F1 = data[output_columns_F1]
y_F2 = data[output_columns_F2]

# Split the data into training, validation, and testing sets
X_train, X_temp, y_F1_train, y_F1_temp = train_test_split(X, y_F1, test_size=0.3, random_state=42)
X_val, X_test, y_F1_val, y_F1_test = train_test_split(X_temp, y_F1_temp, test_size=0.5, random_state=42)

# Create the corresponding y_F2 sets using the same indices
y_F2_train = data[output_columns_F2].iloc[y_F1_train.index].reset_index(drop=True)
y_F2_val = data[output_columns_F2].iloc[y_F1_val.index].reset_index(drop=True)
y_F2_test = data[output_columns_F2].iloc[y_F1_test.index].reset_index(drop=True)

# Function to create MLP model
def create_mlp(input_shape, output_shape):
    model = keras.Sequential([
        layers.Input(shape=(input_shape,)),
        layers.Dense(100, activation='relu'),
        layers.Dense(100, activation='relu'),
        layers.Dense(100, activation='relu'),
        
        layers.Dense(output_shape, activation='tanh')  # Output layer
    ])
    #model.compile(optimizer='adam', loss=Huber())
    model.compile(optimizer='adam', loss='mean_squared_error')
    return model


# Create models
model_F1 = create_mlp(X_train.shape[1], y_F1_train.shape[1])
model_F2 = create_mlp(X_train.shape[1] + 1, y_F2_train.shape[1])  # +1 for am input

# Train the first MLP (for F1)
history_F1 = model_F1.fit(X_train, y_F1_train, 
                           validation_data=(X_val, y_F1_val), 
                           epochs=2000, 
                           batch_size=128)

# Predict am using the first MLP
a_m_hat_train = model_F1.predict(X_train)
a_m_hat_val = model_F1.predict(X_val)
a_m_hat_test = model_F1.predict(X_test)

# Prepare input for F2
X_F2_train = np.hstack((X_train, a_m_hat_train))
X_F2_val = np.hstack((X_val, a_m_hat_val))
X_F2_test = np.hstack((X_test, a_m_hat_test))

# Train the second MLP (for F2)
history_F2 = model_F2.fit(X_F2_train, y_F2_train, 
                           validation_data=(X_F2_val, y_F2_val), 
                           epochs=2000, 
                           batch_size=128)

# Predict rm using the second MLP
r_m_hat_train = model_F2.predict(X_F2_train)
r_m_hat_val = model_F2.predict(X_F2_val)
r_m_hat_test = model_F2.predict(X_F2_test)

# Evaluate the models
loss_F1 = model_F1.evaluate(X_val, y_F1_val)
loss_F2 = model_F2.evaluate(X_F2_val, y_F2_val)

print(f'Validation Loss for Model F1: {loss_F1}')
print(f'Validation Loss for Model F2: {loss_F2}')

# ------------------- Plot training history for F1 -------------------
plt.figure(figsize=(8, 6))
plt.plot(history_F1.history['loss'], label='Train Loss', linewidth=2)
plt.plot(history_F1.history['val_loss'], label='Validation Loss', linewidth=2)

# Title and axis labels bold
plt.title('Model F1 Loss', fontsize=16, fontweight='bold')
plt.xlabel('Epochs', fontsize=14, fontweight='bold')
plt.ylabel('Loss', fontsize=14, fontweight='bold')

# Legend bold & bigger
plt.legend(fontsize=12, frameon=True)
plt.grid(False)

# Save high-resolution image
plt.tight_layout()
plt.savefig('F1Loss.png', dpi=300, bbox_inches='tight')
plt.show()

# ------------------- Plot training history for F2 -------------------
plt.figure(figsize=(8, 6))
plt.plot(history_F2.history['loss'], label='Train Loss', linewidth=2)
plt.plot(history_F2.history['val_loss'], label='Validation Loss', linewidth=2)

# Title and axis labels bold
plt.title('Model F2 Loss', fontsize=16, fontweight='bold')
plt.xlabel('Epochs', fontsize=14, fontweight='bold')
plt.ylabel('Loss', fontsize=14, fontweight='bold')

# Legend bold & bigger
plt.legend(fontsize=12, frameon=True)
plt.grid(False)

# Save high-resolution image
plt.tight_layout()
plt.savefig('F2Loss.png', dpi=300, bbox_inches='tight')
plt.show()

num_samples = 30
N = np.arange(1, num_samples + 1)

# Convert to NumPy arrays and then flatten
y_F1_test_sample = y_F1_test[:num_samples].values.flatten()  # True am values
a_m_hat_test_sample = a_m_hat_test[:num_samples].flatten()   # Estimated am values
y_F2_test_sample = y_F2_test[:num_samples].values.flatten()  # True rm values
r_m_hat_test_sample = r_m_hat_test[:num_samples].flatten()   # Estimated rm values

# Create the figure and subplots
plt.figure(figsize=(6, 8))

# Subplot for am
plt.figure(figsize=(8, 6))  # Better figure size

plt.subplot(2, 1, 1)
plt.plot(N, y_F1_test_sample, 'k--', label='True', markersize=5)  # True values with dashed line
plt.plot(N, a_m_hat_test_sample, 'ro', label='Estimated', markersize=5)  # Estimated values with red circles
plt.xlabel('$N$', fontsize=14, fontweight='bold')      # X-axis bold
plt.ylabel('$V_A$', fontsize=14, fontweight='bold')    # Y-axis bold
plt.legend(loc='upper right', fontsize=12, frameon=True)  # Legend bold
plt.grid(False)

# Subplot for rm
plt.subplot(2, 1, 2)
plt.plot(N, y_F2_test_sample, 'k--', label='True', markersize=5)  # True values with dashed line
plt.plot(N, r_m_hat_test_sample, 'ro', label='Estimated', markersize=5)  # Estimated values with red circles
plt.xlabel('$N$', fontsize=14, fontweight='bold')      # X-axis bold
plt.ylabel('$V_R$', fontsize=14, fontweight='bold')    # Y-axis bold
plt.legend(loc='upper right', fontsize=12, frameon=True)  # Legend bold
plt.grid(False)

# Adjust spacing between subplots
plt.tight_layout()

# Save figure in high resolution
plt.savefig('MSE.png', dpi=300, bbox_inches='tight')
plt.show()

# Inverse transform the predictions and true values to get them back to the original scale
a_m_hat_test_all_original = output_scaler_F1.inverse_transform(a_m_hat_test)  # Predicted am in original scale
y_F1_test_all_original = output_scaler_F1.inverse_transform(y_F1_test.values)  # True am in original scale

r_m_hat_test_all_original = output_scaler_F2.inverse_transform(r_m_hat_test)  # Predicted rm in original scale
y_F2_test_all_original = output_scaler_F2.inverse_transform(y_F2_test.values)  # True rm in original scale

# Create a DataFrame to store the results
results_df = pd.DataFrame({
    'N': np.arange(1, len(a_m_hat_test_all_original) + 1),  # Sample indices
    'True_am': y_F1_test_all_original.flatten(),  # True am values in original scale
    'Estimated_am': a_m_hat_test_all_original.flatten(),  # Predicted am values in original scale
    'True_rm': y_F2_test_all_original.flatten(),  # True rm values in original scale
    'Estimated_rm': r_m_hat_test_all_original.flatten()  # Predicted rm values in original scale
})

# Save the results to a CSV file
results_df.to_csv('predicted_Vr_Va_all_samples.csv', index=False)

print("Predicted am and rm values for all test samples have been saved to 'predicted_am_rm_all_samples.csv'.")

# # Save the models to .h5 files
model_F1.save('model_F1.h5')  # Saves the F1 model
model_F2.save('model_F2.h5')  # Saves the F2 model



# Validation Loss for Model F1: 0.0015159626491367817
# Validation Loss for Model F2: 0.00018536056450102478